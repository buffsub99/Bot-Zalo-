import random
import re
from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from datetime import datetime

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies, allowed_group_name):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.allowed_group_name = allowed_group_name
        self.users = {}

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        group_name = self.fetchGroupName(thread_id)  # Fetch the group name
        if group_name != self.allowed_group_name:
            return  # Ignore messages from groups other than the allowed one

        print(f"Received message: {message} from {author_id} in group {group_name}")

        if not isinstance(message, str):
            print(f"Unexpected message type: {type(message)}")
            return

        if message.startswith(".dangky"):
            username = message[8:].strip()
            if username:
                if author_id not in self.users:
                    self.users[author_id] = {"username": username, "balance": 100000000}
                    response = f"Đăng ký thành công! {username} đã nhận 100 triệu."
                else:
                    response = "Bạn đã đăng ký rồi."
            else:
                response = "Vui lòng cung cấp tên đăng ký."
            self.send(Message(text=response), thread_id, thread_type)
        elif message == ".help":
            help_text = (
                "Cách dùng các lệnh:\n"
                ".dangky (tên): Đăng ký người dùng và nhận 100 triệu\n"
                ".sodu: Kiểm tra số dư hiện có\n"
                ".taixiu (tai/xiu) (số tiền): Chơi tài xỉu"
            )
            self.send(Message(text=help_text), thread_id, thread_type)
        elif message.startswith(".sodu"):
            if author_id in self.users:
                balance = self.users[author_id]["balance"]
                response = f"Số dư hiện tại của bạn là: {balance}"
            else:
                response = "Bạn chưa đăng ký. Vui lòng đăng ký bằng cách dùng lệnh .dangky (tên)."
            self.send(Message(text=response), thread_id, thread_type)
        elif message.startswith(".taixiu"):
            if author_id in self.users:
                try:
                    parts = message.split()
                    choice = parts[1]
                    amount = int(parts[2])
                    if choice not in ["tai", "xiu"]:
                        response = "Lựa chọn không hợp lệ. Vui lòng chọn 'tai' hoặc 'xiu'."
                    elif amount <= 0:
                        response = "Số tiền phải lớn hơn 0."
                    elif amount > self.users[author_id]["balance"]:
                        response = "Số dư không đủ."
                    else:
                        outcome = random.choice(["tai", "xiu"])
                        if outcome == choice:
                            self.users[author_id]["balance"] += amount
                            response = f"Kết quả là {outcome}. Bạn đã thắng {amount}."
                        else:
                            self.users[author_id]["balance"] -= amount
                            response = f"Kết quả là {outcome}. Bạn đã thua {amount}."
                except (IndexError, ValueError):
                    response = "Sai cú pháp. Vui lòng dùng lệnh .taixiu (tai/xiu) (số tiền)."
            else:
                response = "Bạn chưa đăng ký. Vui lòng đăng ký bằng cách dùng lệnh .dangky (tên)."
            self.send(Message(text=response), thread_id, thread_type)
        else:
            self.send(Message(text="Lệnh không hợp lệ. Vui lòng dùng lệnh .help để xem các lệnh hợp lệ."), thread_id, thread_type)

    def fetchGroupName(self, thread_id):
        # Giả sử có một phương thức để lấy tên nhóm từ thread_id
        # Bạn cần thay thế phần này bằng cách lấy tên nhóm thực sự từ API của Zalo
        return "test"  # Thay thế "test" bằng cách gọi API thực tế

    def listen(self):
        while True:
            try:
                messages = self.getNewMessages()  # Cập nhật phương thức đúng để lấy tin nhắn mới
                for message in messages:
                    self.onMessage(
                        mid=message.mid,
                        author_id=message.author_id,
                        message=message.text,
                        message_object=message,
                        thread_id=message.thread_id,
                        thread_type=message.thread_type
                    )
            except ZaloAPIException as e:
                print(f"Error occurred: {e}")
            time.sleep(1)  # Chờ một giây trước khi lấy tin nhắn tiếp theo

imei = "3c3ec473-6e5b-4ba3-9d39-7553ecedbee1-b78b4e2d6c0a362c418b145fe44ed73f"
session_cookies = {"_gid":"GA1.2.897939558.1721915047","_ga_VM4ZJE1265":"GS1.2.1721915047.1.0.1721915047.0.0.0","zputm_source":"","zputm_medium":"","zputm_campaign":"","zpsrc":"","_ga_1J0YGQPT22":"GS1.1.1721970877.1.1.1721971425.57.0.0","_ga":"GA1.2.899747783.1721915047","_zlang":"vn","zpsid":"P-mN.366410262.6.Du8OTTdFX8NFDLAGrS-4XQoyzhRl-R2qwVsojwpCUu7g8TmOsDIt9h_FX8K","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8yud-cYd4fQZ7ISwABHGbgFSPtfgpar.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8yud-cYd4fQZ7ISwABHGbgFSPtfgpar.1","app.event.zalo.me":"3064628943094513678","zpw_sek":"s3qj.366410262.a0.u_Z3EiEidlhLLaZlugoU-hYE-v7XbhojklhziV3sn9ssbQYAkzh_iORVhwsIaQFOljcT1SUVSA9UhUIsOCgU-W"}

# Yêu cầu tên nhóm khi khởi chạy chương trình
allowed_group_name = input("Nhập tên nhóm: ")

client = Client('api_key', 'secret_key', imei=imei, session_cookies=session_cookies, allowed_group_name=allowed_group_name)
client.listen()
